package com.example.ac1;

public class Livro {
    private String titulo;

    private String autor;

    private Boolean lido;

    public Livro(String titulo, Boolean lido, String autor) {
        this.titulo = titulo;
        this.lido = lido;
        this.autor = autor;
    }

    public Livro() {
    }

    public Boolean getLido() {
        return lido;
    }

    public void setLido(Boolean lido) {
        this.lido = lido;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
}
