package com.example.ac1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Livro> livros = new ArrayList<>();
    private LinearLayout listContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText editTitulo = findViewById(R.id.editTitle);
        EditText editAutor = findViewById(R.id.editAutor);
        CheckBox checkBoxLido = findViewById(R.id.checkBoxLido);
        Button btnEnviar = findViewById(R.id.btnEnviar);
        listContainer = findViewById(R.id.checkBoxContainer);

        editTitulo.setHint("Digite o nome do livro");
        editAutor.setHint("Digite o nome do autor");

        btnEnviar.setOnClickListener(v -> {
            String titulo = editTitulo.getText().toString();
            String autor = editAutor.getText().toString();
            boolean lido = checkBoxLido.isChecked();

            if (titulo.isEmpty() || autor.isEmpty()) {
                Toast.makeText(MainActivity.this, "preencha todos os campos", Toast.LENGTH_SHORT).show();
            } else {
                Livro novoLivro = new Livro(titulo, lido, autor);
                livros.add(novoLivro);
                exibirLivros();
                editTitulo.setText("");
                editAutor.setText("");
                checkBoxLido.setChecked(false);
            }
        });
    }

    private void exibirLivros() {
        listContainer.removeAllViews();

        for (Livro livro : livros) {
            TextView textViewLivro = new TextView(this);
            String status = livro.getLido() ? "Lido" : "Não Lido";
            textViewLivro.setText("Título: " + livro.getTitulo() + "\nAutor: " + livro.getAutor() + "\nStatus: " + status);
            listContainer.addView(textViewLivro);
        }
    }
}