package com.example.ac2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private CheckBox edtCinema;
    private EditText edtTitulo, edtDiretor, edtAno, edtGenero, edtNota, edtFiltroGenero;
    private RecyclerView recyclerFilmes;
    private List<Filmes> listaFilmesOriginal = new ArrayList<>();
    private FilmesAdapter adapter;
    private Filmes filmesEditando = null;
    private Button btnFiltrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = FirebaseFirestore.getInstance();

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDiretor = findViewById(R.id.edtDiretor);
        edtGenero = findViewById(R.id.edtGenero);
        edtAno = findViewById(R.id.edtAno);
        edtNota = findViewById(R.id.edtNota);
        edtCinema = findViewById(R.id.checkCinema);
        edtFiltroGenero = findViewById(R.id.edtFiltroGenero);
        btnFiltrar = findViewById(R.id.btnFiltrar);

        recyclerFilmes = findViewById(R.id.recyclerFilmes);
        recyclerFilmes.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FilmesAdapter(new ArrayList<>());
        recyclerFilmes.setAdapter(adapter);

        findViewById(R.id.btnSalvar).setOnClickListener(v -> salvarFilme());

        adapter.setOnItemClickListener(filmes -> {
            edtTitulo.setText(filmes.getTitulo());
            edtDiretor.setText(filmes.getDiretor());
            edtAno.setText(filmes.getAno());
            edtNota.setText(filmes.getNota() != null ? filmes.getNota().toString() : "");
            edtGenero.setText(filmes.getGenero());
            edtCinema.setChecked(filmes.getCinema() != null && filmes.getCinema());
            filmesEditando = filmes;
            ((Button) findViewById(R.id.btnSalvar)).setText("Atualizar filme");
        });

        adapter.setOnItemLongClickListener(filmes -> {
            deletarFilme(filmes.getId());
            return true;
        });

        btnFiltrar.setOnClickListener(v -> {
            String generoFiltro = edtFiltroGenero.getText().toString().trim().toLowerCase();
            if (generoFiltro.isEmpty()) {
                adapter.atualizarLista(listaFilmesOriginal);
            } else {
                List<Filmes> listaFiltrada = new ArrayList<>();
                for (Filmes f : listaFilmesOriginal) {
                    if (f.getGenero() != null && f.getGenero().toLowerCase().contains(generoFiltro)) {
                        listaFiltrada.add(f);
                    }
                }
                adapter.atualizarLista(listaFiltrada);
            }
        });

        carregarFilmes();
    }

    private void salvarFilme() {
        String Titulo = edtTitulo.getText().toString();
        String Diretor = edtDiretor.getText().toString();
        String Ano = edtAno.getText().toString();
        String Genero = edtGenero.getText().toString();
        Boolean Cinema = edtCinema.isChecked();

        String notaStr = edtNota.getText().toString();
        Integer Nota = null;
        if (!notaStr.isEmpty()) {
            Nota = Integer.parseInt(notaStr);
        }

        if (filmesEditando == null) {
            Filmes filmes = new Filmes(null, Titulo, Diretor, Ano, Nota, Genero, Cinema);
            db.collection("filmes")
                    .add(filmes)
                    .addOnSuccessListener(doc -> {
                        filmes.setId(doc.getId());
                        Toast.makeText(this, "Filme salvo!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        carregarFilmes();
                    });
        } else {
            filmesEditando.setTitulo(Titulo);
            filmesEditando.setDiretor(Diretor);
            filmesEditando.setAno(Ano);
            filmesEditando.setGenero(Genero);
            filmesEditando.setNota(Nota);
            filmesEditando.setCinema(Cinema);

            db.collection("filmes").document(filmesEditando.getId())
                    .set(filmesEditando)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                        carregarFilmes();
                    });
        }
    }

    private void limparCampos() {
        edtTitulo.setText("");
        edtDiretor.setText("");
        edtGenero.setText("");
        edtAno.setText("");
        edtNota.setText("");
        edtCinema.setChecked(false);
        filmesEditando = null;
        ((Button) findViewById(R.id.btnSalvar)).setText("Salvar filme");
    }

    private void carregarFilmes() {
        db.collection("filmes")
                .get()
                .addOnSuccessListener(query -> {
                    listaFilmesOriginal.clear();
                    for (QueryDocumentSnapshot doc : query) {
                        Filmes f = doc.toObject(Filmes.class);
                        f.setId(doc.getId());
                        listaFilmesOriginal.add(f);
                    }
                    adapter.atualizarLista(listaFilmesOriginal);
                });
    }

    private void deletarFilme(String id) {
        db.collection("filmes").document(id)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Filme deletado!", Toast.LENGTH_SHORT).show();
                    carregarFilmes();
                });
    }
}