package com.example.ac2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FilmesAdapter extends RecyclerView.Adapter<FilmesAdapter.ViewHolder> {
    private List<Filmes> filmes;

    public interface OnItemClickListener {
        void onItemClick(Filmes filmes);
    }
    private OnItemClickListener clickListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.clickListener = listener;
    }

    public interface OnItemLongClickListener {
        boolean onItemLongClick(Filmes filmes);
    }
    private OnItemLongClickListener longClickListener;

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    public FilmesAdapter(List<Filmes> filmes) {
        this.filmes = filmes;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Filmes f = filmes.get(position);

        holder.txt1.setText(f.getTitulo());
        String detalhes = "Ano: " + f.getAno() + " | Nota: " + f.getNota() + " | Gênero: " + f.getGenero();
        holder.txt2.setText(detalhes);

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onItemClick(f);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                return longClickListener.onItemLongClick(f);
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return filmes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt1, txt2;
        public ViewHolder(View itemView) {
            super(itemView);
            txt1 = itemView.findViewById(android.R.id.text1);
            txt2 = itemView.findViewById(android.R.id.text2);
        }
    }

    public void removerFilme(int position) {
        filmes.remove(position);
        notifyItemRemoved(position);
    }

    public void atualizarLista(List<Filmes> novaLista) {
        this.filmes = novaLista;
        notifyDataSetChanged();
    }
}
