package com.example.ac2;

public class Filmes {
    private String id;
    private String Titulo;
    private String Diretor;
    private String Ano;
    private Integer Nota;
    private String Genero;
    private Boolean Cinema;

    public Filmes() {}

    public Filmes(String id, String Titulo, String Diretor, String Ano, Integer Nota, String Genero, Boolean Cinema) {
        this.id = id;
        this.Titulo = Titulo;
        this.Diretor = Diretor;
        this.Ano = Ano;
        this.Nota = Nota;
        this.Genero = Genero;
        this.Cinema = Cinema;
    }

    public String getId() { return id; }
    public String getTitulo() { return Titulo; }
    public String getDiretor() { return Diretor; }
    public String getAno() { return Ano; }
    public Integer getNota() { return Nota; }
    public String getGenero() { return Genero; }
    public Boolean getCinema() { return Cinema; }

    public void setId(String id) { this.id = id; }
    public void setTitulo(String titulo) { this.Titulo = titulo; }
    public void setDiretor(String diretor) { this.Diretor = diretor; }
    public void setAno(String ano) { this.Ano = ano; }
    public void setNota(Integer nota) { this.Nota = nota; }
    public void setGenero(String genero) { this.Genero = genero; }
    public void setCinema(Boolean cinema) { this.Cinema = cinema; }
}
