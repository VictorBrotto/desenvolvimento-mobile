package com.example.medicontrol;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class MedicineAdapter extends RecyclerView.Adapter<MedicineAdapter.ViewHolder> {

    private List<Medicine> lista;
    private OnItemClickListener listener;
    private Context context;

    public interface OnItemClickListener {
        void onItemClick(Medicine medicine);
        void onTomarClick(Medicine medicine);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public MedicineAdapter(List<Medicine> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // ... seu código existente sem alterações ...
        Context context = parent.getContext();

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        layout.setPadding(16, 16, 16, 16);

        LinearLayout textos = new LinearLayout(context);
        textos.setOrientation(LinearLayout.VERTICAL);
        textos.setLayoutParams(new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));

        TextView txtNome = new TextView(context);
        txtNome.setId(View.generateViewId());

        TextView txtHorario = new TextView(context);
        txtHorario.setId(View.generateViewId());

        textos.addView(txtNome);
        textos.addView(txtHorario);

        Button btnTomar = new Button(context);
        btnTomar.setId(View.generateViewId());
        btnTomar.setText(context.getString(R.string.btn_tomar));

        layout.addView(textos);
        layout.addView(btnTomar);

        return new ViewHolder(layout, txtNome, txtHorario, btnTomar);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Medicine m = lista.get(position);

        holder.txtNome.setText(m.getNome());
        holder.txtHorario.setText(m.getHorario());

        if (m.isTomado()) {
            holder.btnTomar.setText(context.getString(R.string.btn_tomado));
            holder.btnTomar.setEnabled(false);
            holder.itemView.setBackgroundColor(0xFFE8F5E9);
        } else {
            holder.btnTomar.setText(context.getString(R.string.btn_tomar));
            holder.btnTomar.setEnabled(true);
            holder.itemView.setBackgroundColor(0xFFFFFFFF);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(m);
        });

        holder.itemView.setOnLongClickListener(v -> {
            // SALVA O ID DO MEDICAMENTO ANTES DE REMOVER
            String medicamentoId = m.getId();

            FirebaseDatabase.getInstance().getReference("medicamentos")
                    .child(medicamentoId)
                    .removeValue()
                    .addOnSuccessListener(a -> {
                        // BUSCA A POSIÇÃO ATUAL DO MEDICAMENTO NA LISTA
                        int posicaoAtual = -1;
                        for (int i = 0; i < lista.size(); i++) {
                            if (lista.get(i).getId().equals(medicamentoId)) {
                                posicaoAtual = i;
                                break;
                            }
                        }

                        // SE ENCONTROU, REMOVE
                        if (posicaoAtual != -1) {
                            lista.remove(posicaoAtual);
                            notifyItemRemoved(posicaoAtual);
                            Toast.makeText(context, R.string.msg_excluido, Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, R.string.msg_erro_excluir, Toast.LENGTH_SHORT).show();
                    });
            return true;
        });

        holder.btnTomar.setOnClickListener(v -> {
            if (listener != null) listener.onTomarClick(m);
        });
    }

    @Override
    public int getItemCount() {
        return lista == null ? 0 : lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtNome, txtHorario;
        Button btnTomar;

        public ViewHolder(View itemView, TextView txtNome, TextView txtHorario, Button btnTomar) {
            super(itemView);
            this.txtNome = txtNome;
            this.txtHorario = txtHorario;
            this.btnTomar = btnTomar;
        }
    }
}