package com.example.medicontrol;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class ApiActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> lista = new ArrayList<>();
    ArrayAdapter<String> adapter;
    Button btnCarregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_api);

        listView = findViewById(R.id.listApi);
        btnCarregar = findViewById(R.id.btnCarregar);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        listView.setAdapter(adapter);

        btnCarregar.setOnClickListener(v -> new BuscarMedicamentosCompletos().execute());
    }

    private class BuscarMedicamentosCompletos extends AsyncTask<Void, Void, ArrayList<String>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(ApiActivity.this, "Buscando informações...", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected ArrayList<String> doInBackground(Void... voids) {
            ArrayList<String> resultado = new ArrayList<>();

            try {
                // Tentar API externa primeiro
                resultado = buscarDeAPIExterna();

                // Se não retornar resultados, usar dados locais
                if (resultado.isEmpty() || resultado.get(0).contains("Erro")) {
                    resultado = getBancoMedicamentosCompleto();
                }

            } catch (Exception e) {
                resultado = getBancoMedicamentosCompleto(); // Fallback
            }

            return resultado;
        }

        @Override
        protected void onPostExecute(ArrayList<String> resultado) {
            lista.clear();
            lista.addAll(resultado);
            adapter.notifyDataSetChanged();

            if (!lista.isEmpty()) {
                Toast.makeText(ApiActivity.this,
                        lista.size() + " medicamentos carregados",
                        Toast.LENGTH_SHORT).show();
            }
        }

        private ArrayList<String> buscarDeAPIExterna() {
            ArrayList<String> medicamentos = new ArrayList<>();

            try {
                // API de dados abertos de saúde (exemplo genérico)
                URL url = new URL("https://dados.gov.br/api/3/action/package_show?id=medicamentos");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"));

                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                    br.close();

                    // Processar JSON
                    JSONObject json = new JSONObject(sb.toString());
                    // ... processamento específico da API
                }

            } catch (Exception e) {
                // Silencioso - usará fallback
            }

            return medicamentos;
        }
    }

    // Banco de dados local completo de medicamentos em português
    private ArrayList<String> getBancoMedicamentosCompleto() {
        ArrayList<String> medicamentos = new ArrayList<>();

        HashMap<String, String[]> bancoMedicamentos = criarBancoMedicamentos();

        for (HashMap.Entry<String, String[]> entry : bancoMedicamentos.entrySet()) {
            String nome = entry.getKey();
            String[] info = entry.getValue();
            String formato = String.format(
                    "💊 %s\n" +
                            "📋 Uso: %s\n" +
                            "⚕️ Classe: %s\n" +
                            "⚠️ Cuidados: %s",
                    nome, info[0], info[1], info[2]
            );
            medicamentos.add(formato);
        }

        return medicamentos;
    }

    private HashMap<String, String[]> criarBancoMedicamentos() {
        HashMap<String, String[]> medicamentos = new HashMap<>();

        // Medicamento: {Uso, Classe, Cuidados}
        medicamentos.put("Paracetamol", new String[]{
                "Alívio de dor e febre",
                "Analgésico e Antitérmico",
                "Não exceder 4g/dia. Evitar álcool."
        });

        medicamentos.put("Ibuprofeno", new String[]{
                "Inflamações, dor e febre",
                "Anti-inflamatório Não Esteroidal (AINE)",
                "Tomar com alimentos. Evitar em úlceras."
        });

        medicamentos.put("Dipirona", new String[]{
                "Dor intensa e febre",
                "Analgésico e Antitérmico",
                "Pode causar agranulocitose (raro)"
        });

        medicamentos.put("Amoxicilina", new String[]{
                "Infecções bacterianas",
                "Antibiótico (Penicilina)",
                "Completar tratamento. Pode causar diarreia."
        });

        medicamentos.put("Omeprazol", new String[]{
                "Azia, refluxo, úlceras",
                "Inibidor de Bomba de Prótons",
                "Tomar antes do café. Uso prolongado requer cuidado."
        });

        medicamentos.put("Losartana", new String[]{
                "Pressão alta (hipertensão)",
                "Bloqueador de Receptor de Angiotensina II",
                "Monitorar pressão. Não usar na gravidez."
        });

        medicamentos.put("Sinvastatina", new String[]{
                "Reduzir colesterol alto",
                "Estatinas",
                "Tomar à noite. Monitorar função hepática."
        });

        medicamentos.put("Metformina", new String[]{
                "Diabetes tipo 2",
                "Hipoglicemiante Oral",
                "Tomar com alimentos. Risco de acidose láctica."
        });

        medicamentos.put("AAS (Aspirina)", new String[]{
                "Dor, inflamação, prevenir coágulos",
                "Antiagregante Plaquetário",
                "Pode causar sangramento. Evitar em crianças."
        });

        medicamentos.put("Loratadina", new String[]{
                "Alergias, rinite, urticária",
                "Anti-histamínico",
                "Pode causar sonolência. Evitar álcool."
        });

        medicamentos.put("Salbutamol", new String[]{
                "Asma, bronquite",
                "Broncodilatador",
                "Uso em crises. Não exceder dose."
        });

        medicamentos.put("Hidroclorotiazida", new String[]{
                "Pressão alta, inchaço",
                "Diurético",
                "Tomar de manhã. Pode causar cãibras."
        });

        return medicamentos;
    }
}