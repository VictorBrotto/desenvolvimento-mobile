package com.example.medicontrol;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DatabaseReference dbRef;
    RecyclerView recycler;
    ArrayList<Medicine> lista = new ArrayList<>();
    MedicineAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Definir título da Activity usando string internacionalizada
        setTitle(R.string.title_main);

        criarCanalNotificacao();

        dbRef = FirebaseDatabase.getInstance().getReference("medicamentos");

        recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        // ✅ MUDANÇA AQUI: Passa 'this' como contexto para o adapter
        adapter = new MedicineAdapter(lista, this);

        adapter.setOnItemClickListener(new MedicineAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Medicine medicine) {
                Intent i = new Intent(MainActivity.this, AddEditMedicineActivity.class);
                i.putExtra("id", medicine.getId());
                i.putExtra("nome", medicine.getNome());
                i.putExtra("descricao", medicine.getDescricao());
                i.putExtra("horario", medicine.getHorario());
                i.putExtra("tomado", medicine.isTomado());
                startActivity(i);
            }

            @Override
            public void onTomarClick(Medicine medicine) {
                marcarComoTomado(medicine);
            }
        });

        recycler.setAdapter(adapter);

        FloatingActionButton btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddEditMedicineActivity.class));
        });

        Button btnApi = findViewById(R.id.btnApi);
        btnApi.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ApiActivity.class));
        });
    }

    private void criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // ✅ Usa string internacionalizada para nome do canal
            NotificationChannel canal = new NotificationChannel(
                    "meds",
                    getString(R.string.canal_notificacao),
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(canal);
        }
    }

    private void marcarComoTomado(Medicine medicine) {
        medicine.setTomado(true);
        dbRef.child(medicine.getId()).setValue(medicine)
                .addOnSuccessListener(a -> {
                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    Intent intent = new Intent(this, AlarmReceiver.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this,
                            medicine.getId().hashCode(),
                            intent,
                            PendingIntent.FLAG_IMMUTABLE
                    );

                    if (alarmManager != null) {
                        alarmManager.cancel(pendingIntent);
                    }

                    // ✅ Mensagem internacionalizada
                    String mensagem = medicine.getNome() + " " +
                            getString(R.string.btn_tomado).toLowerCase() + "!";
                    Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show();
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, R.string.msg_erro_excluir, Toast.LENGTH_SHORT).show();
                });
    }

    private void carregarLista() {
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                lista.clear();
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    Medicine m = itemSnapshot.getValue(Medicine.class);
                    if (m != null) {
                        m.setId(itemSnapshot.getKey());
                        lista.add(m);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Opcional: mostrar mensagem de erro
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }
}